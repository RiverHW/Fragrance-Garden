//
//  main.m
//  DianQhome
//
//  Created by 何江伟 on 2017/10/30.
//  Copyright © 2017年 何江伟. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
