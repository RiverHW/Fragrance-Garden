//
//  AppDelegate.h
//  DianQhome
//
//  Created by 何江伟 on 2017/10/30.
//  Copyright © 2017年 何江伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

