//
//  HomeCollectionViewCell.m
//  DianQhome
//
//  Created by 何江伟 on 2017/10/30.
//  Copyright © 2017年 何江伟. All rights reserved.
//

#import "HomeCollectionViewCell.h"

@implementation HomeCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.backgroundColor = [UIColor orangeColor];
}

@end
