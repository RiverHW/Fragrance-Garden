//
//  MBProgressHUD+HM.h
//  SearchCard
//
//  Created by YHM on 2017/3/27.
//  Copyright © 2017年 welink. All rights reserved.
//

#import <MBProgressHUD/MBProgressHUD.h>

@interface MBProgressHUD (HM)


/**
 显示信息

 @param message 信息内容
 */
+ (void)showMessage:(NSString *)message;

/**
 显示信息

 @param text 信息内容
 @param icon 信息图片
 @param view 显示视图
 */
+ (void)show:(NSString *)text icon:(NSString *)icon view:(UIView *)view;

/**
 加载动画

 @param view 显示的视图
 */
+ (void)showHUDAddedToView:(UIView *)view;


/**
 取消加载动画

 @param view HUD显示的视图
 */
+ (void)removeHUDView:(UIView *)view;



+ (void)showError:(NSString *)error;


@end
