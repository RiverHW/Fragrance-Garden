//
//  PathMacro.h
//  Template
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 陈123. All rights reserved.
//

#ifndef PathMacro_h
#define PathMacro_h


/**
 *  沙盒
 */
//Home(根路径)
#define kPathHome NSHomeDirectory()
//Documents
#define kPathDocument (NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0])
//Library
#define kPathCacheLibrary (NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES)[0])
//Cache
#define kPathCache (NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0])
//tmp
#define TMP_DIRECTORY NSTemporaryDirectory()

#define kApplication ((AppDelegate*) [[UIApplication sharedApplication] delegate])

/**
 *  Bundle
 */
#define kPathBundle ([NSBundle mainBundle])

//Bundle文件路径
#define FilePathInBundleWithNameAndType(name,type) ([kPathBundle pathForResource:name ofType:type])



#define addressPlistPath  ([NSString stringWithFormat:@"%@addressChoose.plist", TMP_DIRECTORY])        // 省市区plist缓存地址


//文件目录














#define ThisWeak(weakSelf)  __weak __typeof(&*self)weakSelf = self




#endif /* PathMacro_h */
