//
//  DimensMacros.h
//  Template
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 陈123. All rights reserved.
//

#ifndef DimensMacros_h
#define DimensMacros_h


//状态栏高度
#define STATUS_BAR_HEIGHT 20.0

//NavBar高度
#define NAVIGATION_BAR_HEIGHT 44.0

//状态栏 ＋ 导航栏 高度
#define STATUS_AND_NAVIGATION_HEIGHT ((STATUS_BAR_HEIGHT) + (NAVIGATION_BAR_HEIGHT))

// TabBar高度
#define TAB_BAR_HEIGHT 49.0

//屏幕 rect
#define SCREEN_RECT ([UIScreen mainScreen].bounds)      // 屏幕尺寸

/**
 *  获取当前屏幕的宽度和高度
 */
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)              // 屏幕宽度
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)            // 屏幕高度

#define SCREEN_WIDTH_SCALE (SCREEN_WIDTH / 375.0)      // 和 6S 的宽度比
#define SCREEN_HEIGHT_SCALE (SCREEN_HEIGHT / 667.0)    // 和 6 的高度比
#define SCREEN_OPERATION_HEIGHT_SCALE ((SCREEN_HEIGHT - 113.0) / 554.0)     // 和 6 取出导航栏、状态栏、TabBar的高度比
#define SCREEN_NAVBAR_HEIGHT_SCALE ((SCREEN_HEIGHT - 64.0) / 603.0)     // 和 6 取出导航栏、状态栏的高度比


// 去除导航栏、状态栏高度
#define CONTENT_HEIGHT (SCREEN_HEIGHT - NAVIGATION_BAR_HEIGHT - STATUS_BAR_HEIGHT)

//屏幕分辨率
#define SCREEN_RESOLUTION (SCREEN_WIDTH * SCREEN_HEIGHT * ([UIScreen mainScreen].scale))



//----------------------系统----------------------------

/**
 *  获取系统版本
 */
#define SYSTEM_VERSION_NUMBER [[[UIDevice currentDevice] systemVersion] floatValue]
#define SYSTEM_VERSION [[UIDevice currentDevice] systemVersion]

//判断设备的操做系统是不是ios8以上
#define SYSTEM_VERSION_8 (SYSTEM_VERSION_NUMBER >= 8.0)

//获取当前语言
#define CurrentLanguage ([[NSLocale preferredLanguages] objectAtIndex:0])


/*账号密码 宏定义区*/
#define MobRegisterApp @"14c91a6be57be"
#define MobSecret @"48a642ba75b3ffb0561cdeb321415b44"
#define kAppStoreAppleId @"1140044137"
#define sinaAppKey @"3099024616"
#define sinaSecret @"023baef6de646c50a4b0df4c49c49488"
#define WeixinAppId @"wx7cb72fb41a10b8a6"
#define WeixinSecret @"9730e122055c3fd61f1ea4e6ec1bdbb0"
#define MobRegisterApp @"14c91a6be57be"
#define MobSecret @"48a642ba75b3ffb0561cdeb321415b44"
#define UMAppKey @"57974ae0e0f55aca910012a6"
#define UMSinaAppKey @"941248481"
#define UMSinaSecret @"0c4bfd36f58455ba9c715c5cfa344b70"
#define QQAppKey @"1105548688"
#define QQAppSecret @"80NAPiSfJQ6rZ3s5"




#endif /* DimensMacros_h */
