//
//  UtilsMacros.h
//  Template
//
//  Created by Apple on 16/8/16.
//  Copyright © 2016年 陈123. All rights reserved.
//

#ifndef UtilsMacros_h
#define UtilsMacros_h



//---------------------打印日志--------------------------
/**
 *  打印日志
 */
#ifdef DEBUG
    #define YBEGLOG(format,...)	\
    do{	\
        fprintf(stderr, "<%s : %d> %s\n",[[[NSString stringWithUTF8String:__FILE__] lastPathComponent] UTF8String], __LINE__, __func__);	\
        (NSLog)((format), ##__VA_ARGS__);	\
        fprintf(stderr, "-----------------\n");	\
    } while(0);
#else
    #define YBEGLOG(...)
#endif

/**
 *  矩形日志
 */
#ifdef DEBUG
#define YBEGLOGRect(rect) YBEGLOG(@"%s x:%.4f, y:%.4f, w:%.4f, h:%.4f", #rect, rect.origin.x, rect.origin.y, rect.size.width, rect.size.height)
#else
#define YBEGLOGRect(rect)
#endif

/**
 *  尺寸日志
 */
#ifdef DEBUG
#define YBEGLOGSize(size) YBEGLOG(@"%s w:%.4f, h:%.4f", #size, size.width, size.height)
#else
#define YBEGLOGGSize(size)
#endif


//---------------------打印日志--------------------------





//----------------------颜色类---------------------------
// rgb颜色转换（16进制->10进制）
#define UIColorWithRGB16Radix(rgbValue) ([UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0])

// 获取RGB颜色
#define UIColorWithRGBA(r,g,b,a) ([UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a])

#define UIColorWithRGB(r,g,b) (UIColorWithRGBA(r,g,b,1.0f))

#define UIColorWithName(name) ([UIColor name##Color])

//清除颜色
#define UIColorWithNULL ([UIColor clearColor])


#define RED_COLOR               (UIColorWithRGB16Radix(0XF23030))      // 红色 -- 导航栏颜色

#define PRICE_RED_COLOR         (UIColorWithRGB16Radix(0XEF0505))      // 红色 -- 价格标签颜色

#define BACKGROUND_COLOR        (UIColorWithRGB16Radix(0XF3F3F3))      //背景色
#define WHITE_COLOR             (UIColorWithRGB16Radix(0XFFFFFF))      // 白色
#define LINE_COLOR              (UIColorWithRGB16Radix(0XE1E1E1))      // 分割线颜色

#define LINE_SHALLOW_COLOR      (UIColorWithRGB16Radix(0XF2F4F6))      // 分割线较浅颜色
#define TEXT_COLOR              (UIColorWithRGB16Radix(0X434343))      // 字体颜色
#define PLACEHOLDER_TEXT_COLOR  (UIColorWithRGB16Radix(0XCCCCCC))      // 占位字体颜色颜色

#define GREEN_COLOR             (UIColorWithRGB16Radix(0X3DBD87))      // 绿色
#define BLUE_COLOR              UIColorWithRGB(54, 158, 243)      // 蓝色

#define SUBTITLE_TEXT_COLOR     (UIColorWithRGB16Radix(0X81838D))      // 子标题字体颜色




//----------------------颜色类--------------------------


//----------------------图片----------------------------
//读取本地图片
#define UIImageWithPathAndType(path,type) ([UIImage imageWithContentsOfFile:[[NSBundle mainBundle]pathForResource:path ofType:type]])

//定义UIImage对象
#define UIImageWithPath(path) ([UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:path ofType:nil]])

//定义UIImage对象
#define UIImageWithName(name) ([UIImage imageNamed:name])

//建议使用前两种宏定义,性能高于后者
//----------------------图片----------------------------


//----------------------字体----------------------------
#define UIFontWithNameAndSize(fontName,fontSize) ([UIFont fontWithName:fontName size:fontSize * SCREEN_WIDTH_SCALE])
#define UIFontWithSize(size) ([UIFont systemFontOfSize:size * SCREEN_WIDTH_SCALE])               // 正常字体大小
#define UIBoldFontWithSize(size) ([UIFont boldSystemFontOfSize:size * SCREEN_WIDTH_SCALE])       // 加粗字体
#define UIItalicFontWithSize(size) ([UIFont italicSystemFontOfSize:size * SCREEN_WIDTH_SCALE])   // 斜体



//----------------------字体----------------------------


//#define getCurentTime [NSString stringWithFormat:@"%ld", (long)[[NSDate date] timeIntervalSince1970]]
//
////角度转弧度
//#define DEGREES_TO_RADIANS(d) (d * M_PI / 180)



#endif /* UtilsMacros_h */
