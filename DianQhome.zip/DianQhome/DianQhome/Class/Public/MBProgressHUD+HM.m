//
//  MBProgressHUD+HM.m
//  SearchCard
//
//  Created by YHM on 2017/3/27.
//  Copyright © 2017年 welink. All rights reserved.
//

#import "MBProgressHUD+HM.h"

@implementation MBProgressHUD (HM)

+ (void)showMessage:(NSString *)message {
    
    UIView *view = [[UIApplication sharedApplication].windows lastObject];
    // 快速显示一个提示信息
    MBProgressHUD *hud = [self showHUDAddedTo:view animated:YES];;
    
    hud.label.text = message;
    hud.label.font = UIFontWithSize(16.0);
    hud.mode = MBProgressHUDModeText;
    
    // 隐藏时候从父控件中移除
    hud.removeFromSuperViewOnHide = YES;
    
    // 1秒之后再消失
    [hud hideAnimated:YES afterDelay:1.0];
}



#pragma mark 显示信息
+ (void)show:(NSString *)text icon:(NSString *)icon view:(UIView *)view {
    if (view == nil) view = [UIApplication sharedApplication].keyWindow;
    // 快速显示一个提示信息
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.label.text = text;
    hud.label.numberOfLines = 0;
    // 设置图片
    hud.customView = [[UIImageView alloc] initWithImage:UIImageWithName(icon)];
    // 再设置模式
    hud.mode = MBProgressHUDModeCustomView;
    // 隐藏时候从父控件中移除
    hud.removeFromSuperViewOnHide = YES;
    // 1秒之后再消失
    [hud hideAnimated:YES afterDelay:1.2];
}



+ (void)showHUDAddedToView:(UIView *)view {
    
    if (view == nil) view = [[UIApplication sharedApplication].delegate window];
    // 快速显示一个提示信息
    MBProgressHUD *hud = [self HUDForView:view];
    if (hud == nil) {
        hud = [self showHUDAddedTo:view animated:YES];
    }

    
}


+ (void)removeHUDView:(UIView *)view {
    if (view == nil) view = [[UIApplication sharedApplication].delegate window];
    [self hideHUDForView:view animated:YES];
}


+ (void)showError:(NSString *)error
{
   [self show:error icon:@"error.png" view:nil];
}




@end
