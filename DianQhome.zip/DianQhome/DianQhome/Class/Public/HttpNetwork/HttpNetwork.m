//
//  HttpNetwork.m
//  IngotEshop
//
//  Created by YHM on 2017/4/7.
//  Copyright © 2017年 陈123. All rights reserved.
//

#import "HttpNetwork.h"
#import <AVFoundation/AVFoundation.h>

#define CompressionVideoPaht [NSHomeDirectory() stringByAppendingFormat:@"/Documents/CompressionVideoField"]


@implementation HttpNetwork

// 定义一个静态成员，保存唯一的实例
static AFHTTPSessionManager *requestManager;
// 保证对象只被分配一次内存空间，通过dispatch_once能够保证单例的分配和初始化是线程安全的



// 保证对象只被初始化一次
+ (id)sharedTools {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        requestManager = [AFHTTPSessionManager manager];
        
        // 不加上这句话，会报“Request failed: unacceptable content-type: text/plain”错误，因为我们要获取text/plain类型数据
        requestManager.responseSerializer = [AFHTTPResponseSerializer serializer];
        requestManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"sparql-results+json", @"text/json", @"text/html",@"text/plain", @"text/xml",@"text/text", nil];
        // post请求
        requestManager.securityPolicy = [AFSecurityPolicy defaultPolicy];
        requestManager.securityPolicy.allowInvalidCertificates = YES;          //忽略https证书
        requestManager.securityPolicy.validatesDomainName = NO;
        
        requestManager.requestSerializer.timeoutInterval = 30.f;        // 设置请求超时时间
        
    });
    return requestManager;
}




+ (NSURLSessionDataTask *)sendPOSTRequestWithParameters:(NSDictionary *)parameters
                                          URLAddressStr:(NSString *)urlAddressStr
                                                success:(responseSuccessBlock)success
                                                failure:(responseFailureBlock)failure {
    [MBProgressHUD showHUDAddedToView:nil];
    
    AFHTTPSessionManager *manager = [HttpNetwork sharedTools];

    manager.requestSerializer.timeoutInterval = 10;
    NSMutableDictionary *paramDic;
    parameters != nil ? (paramDic = [NSMutableDictionary dictionaryWithDictionary:parameters]) : (paramDic = [NSMutableDictionary dictionary]);
    if (KAppDelegate.userModel) {
        [paramDic setObject:KAppDelegate.userModel.userId forKey:@"userId"];
        [paramDic setObject:KAppDelegate.userModel.systemCode forKey:@"systemCode"];
    }
    
    NSLog(@"====%@",[APIServerDomain stringByAppendingString:urlAddressStr]);
    NSURLSessionDataTask *task = [manager POST:[APIServerDomain stringByAppendingString:urlAddressStr] parameters:paramDic constructingBodyWithBlock:^(id _Nonnull formData) {
        // 拼接data到请求体，这个block的参数是遵守56协议的。
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        // 这里可以获取到目前的数据请求的进度
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MBProgressHUD removeHUDView:nil];
        NSDictionary *responseDict = [responseObject mj_JSONObject];
        
        if ([[responseDict objectForKey:@"retState"] integerValue] == 0) {
            success(responseDict);
        } else {
            failure([responseDict objectForKey:@"retMessage"]);
//            [MBProgressHUD showError:[responseDict objectForKey:@"retMessage"]];
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [MBProgressHUD removeHUDView:nil];
        
        NSLog(@"%@",[error.userInfo objectForKey:@"NSLocalizedDescription"] );
        
        if ([(NSString *)[error.userInfo objectForKey:@"NSLocalizedDescription"] containsString:@"offline"]) {
            [MBProgressHUD showError:@"网络不给力,请检查网络设置～"];

        }else if ([(NSString *)[error.userInfo objectForKey:@"NSLocalizedDescription"] containsString:@"timed out"]){
            [MBProgressHUD showError:@"合掌柜开小差了,请稍后重试～"];
        }else{
            [MBProgressHUD showError:[error.userInfo objectForKey:@"NSLocalizedDescription"]];
        }
        failure([error.userInfo objectForKey:@"NSLocalizedDescription"]);
    }];
    
    return task;
}



+ (NSURLSessionDataTask *)sendPOSTRequestNoneMBHudWithParameters:(NSDictionary *)parameters
                                          URLAddressStr:(NSString *)urlAddressStr
                                                success:(responseSuccessBlock)success
                                                failure:(responseFailureBlock)failure {
    
    AFHTTPSessionManager *manager = [HttpNetwork sharedTools];
    
    manager.requestSerializer.timeoutInterval = 10;
    NSMutableDictionary *paramDic;
    parameters != nil ? (paramDic = [NSMutableDictionary dictionaryWithDictionary:parameters]) : (paramDic = [NSMutableDictionary dictionary]);
    if (KAppDelegate.userModel) {
        [paramDic setObject:KAppDelegate.userModel.userId forKey:@"userId"];
        [paramDic setObject:KAppDelegate.userModel.systemCode forKey:@"systemCode"];
    }
    
    NSLog(@"====%@",[APIServerDomain stringByAppendingString:urlAddressStr]);
    NSURLSessionDataTask *task = [manager POST:[APIServerDomain stringByAppendingString:urlAddressStr] parameters:paramDic constructingBodyWithBlock:^(id _Nonnull formData) {
        // 拼接data到请求体，这个block的参数是遵守56协议的。
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        // 这里可以获取到目前的数据请求的进度
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MBProgressHUD removeHUDView:nil];
        NSDictionary *responseDict = [responseObject mj_JSONObject];
        
        if ([[responseDict objectForKey:@"retState"] integerValue] == 0) {
            success(responseDict);
        } else {
            failure([responseDict objectForKey:@"retMessage"]);
            //            [MBProgressHUD showError:[responseDict objectForKey:@"retMessage"]];
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [MBProgressHUD removeHUDView:nil];
        
        NSLog(@"%@",[error.userInfo objectForKey:@"NSLocalizedDescription"] );
        
        if ([(NSString *)[error.userInfo objectForKey:@"NSLocalizedDescription"] containsString:@"offline"]) {
            [MBProgressHUD showError:@"网络不给力,请检查网络设置～"];
            
        }else if ([(NSString *)[error.userInfo objectForKey:@"NSLocalizedDescription"] containsString:@"timed out"]){
            [MBProgressHUD showError:@"合掌柜开小差了,请稍后重试～"];
        }else{
            [MBProgressHUD showError:[error.userInfo objectForKey:@"NSLocalizedDescription"]];
        }
        failure([error.userInfo objectForKey:@"NSLocalizedDescription"]);
    }];
    
    return task;
}



@end
