//
//  APIHttpMacro.h
//  IngotEshop
//
//  Created by YHM on 2017/4/7.
//  Copyright © 2017年 陈123. All rights reserved.
//

#ifndef APIHttpMacro_h
#define APIHttpMacro_h



//#define APIServerDomain @"http://xunka.weilicx.com/?/"

//#define APIServerDomain @"http://192.168.0.200:8083/portMgt/"
//#define APIServerDomain @"http://218.85.121.188:80/portMgt/"

#define APIServerDomain @"http://218.85.121.186:8081/portMgt/"

//#define APIServerWeb @"http://api.xunka520.com/xunka/"
//#define ImageAPIServerDomain @"http://api.qsybeg.com/"
//#define HomeIndex @"index"
//#define APIImagen @"http://api.xunka520.com/api/"

#endif /* APIHttpMacro_h */
