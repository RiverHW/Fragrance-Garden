//
//  HttpNetwork.h
//  IngotEshop
//
//  Created by YHM on 2017/4/7.
//  Copyright © 2017年 陈123. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <Photos/Photos.h>

@interface HttpNetwork : NSObject


//当数据有效地时候
typedef void (^responseSuccessBlock) (id obj);          // 请求成功
typedef void (^responseFailureBlock) (id obj);          // 请求失败
typedef void (^responseCompleteBlock) ();               // 请求完成



+ (id)sharedTools;


#pragma mark -
#pragma mark - POST请求
+ (NSURLSessionDataTask *)sendPOSTRequestWithParameters:(NSDictionary *)parameters
                                          URLAddressStr:(NSString *)urlAddressStr
                                                success:(responseSuccessBlock)success
                                                failure:(responseFailureBlock)failure;


#pragma mark -
#pragma mark - POST请求 NoneHUD

+ (NSURLSessionDataTask *)sendPOSTRequestNoneMBHudWithParameters:(NSDictionary *)parameters
                                          URLAddressStr:(NSString *)urlAddressStr
                                                success:(responseSuccessBlock)success
                                                failure:(responseFailureBlock)failure;




@end
