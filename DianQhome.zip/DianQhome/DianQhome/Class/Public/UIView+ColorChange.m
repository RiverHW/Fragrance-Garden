//
//  UIView+ColorChange.m
//  Pcsk
//
//  Created by 江伟 on 2017/8/28.
//  Copyright © 2017年 江伟. All rights reserved.
//

#import "UIView+ColorChange.h"

@implementation UIView (ColorChange)


- (void)difColorStartPoint:(CGPoint )startPoint endPoint:(CGPoint )endPoint
{
    CAGradientLayer *gradientLayer = [[CAGradientLayer alloc] init];
    gradientLayer.colors = @[(__bridge id)right_Color.CGColor,(__bridge id)left_Color.CGColor];
    gradientLayer.startPoint = startPoint;
    gradientLayer.endPoint = endPoint;
    gradientLayer.frame = CGRectMake(0,0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
    [self.layer addSublayer:gradientLayer];
}

@end
