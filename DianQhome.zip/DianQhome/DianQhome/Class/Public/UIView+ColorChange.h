//
//  UIView+ColorChange.h
//  Pcsk
//
//  Created by 江伟 on 2017/8/28.
//  Copyright © 2017年 江伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ColorChange)


//位置x,y    自己根据需求进行设置   使其从不同位置进行渐变

- (void)difColorStartPoint:(CGPoint )startPoint endPoint:(CGPoint )endPoint;

@end
