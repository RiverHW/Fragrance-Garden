//
//  MessageViewController.h
//  DianQhome
//
//  Created by 何江伟 on 2017/10/30.
//  Copyright © 2017年 何江伟. All rights reserved.
//

#import "HMBaseViewController.h"

@interface MessageViewController : HMBaseViewController

@end
