//
//  HMBaseViewController.m
//  SearchCard
//
//  Created by YHM on 2017/3/22.
//  Copyright © 2017年 welink. All rights reserved.
//

#import "HMBaseViewController.h"

#import "HMBaseNavigationController.h"

//#import <IQKeyboardManager/IQKeyboardManager.h>




@interface HMBaseViewController ()

@property (nonatomic, strong) CATransition *animation;

@property (nonatomic, strong) UIBarButtonItem *rightBarItem;        // 右边按钮

@end

@implementation HMBaseViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    self.view.backgroundColor = BACKGROUND_COLOR;
    self.view.backgroundColor = [UIColor whiteColor];
    
}



#pragma mark -
#pragma mark - 数据初始化懒加载
// TODO: navigationItem
- (UINavigationItem *)baseNavigationItem {
    if (!_baseNavigationItem) {
        _baseNavigationItem = [UINavigationItem new];
        [self baseNavigationBar];
    }
    return _baseNavigationItem;
}

// TODO: baseNavigationBar
- (HMBaseNavigationBar *)baseNavigationBar {
    if (!_baseNavigationBar) {
        _baseNavigationBar = [[HMBaseNavigationBar alloc]initWithFrame:CGRectMake(0.0, 0.0, SCREEN_WIDTH, 64.0)];
        
        [self navBarTintColor:UIColorWithRGB(248, 248, 248) withShadow:YES];
        
        [_baseNavigationBar pushNavigationItem:self.baseNavigationItem animated:YES];
        NSInteger titleSize;
        
        SCREEN_WIDTH < 375?titleSize = 18:(titleSize = 17);
        [_baseNavigationBar setTitleTextAttributes:@{NSFontAttributeName:UIBoldFontWithSize(titleSize), NSForegroundColorAttributeName:UIColorWithRGB(37, 38, 46)}];     // 设置title字体大小颜色
        
        if ([self.navigationController.childViewControllers count] > 1) {
            [self leftBarItemWitihImage:@"nav_return" actionSelector:@selector(popViewControllerAction)];
        }
        [self.view addSubview:self.baseNavigationBar];
    }
    return _baseNavigationBar;
}

// TODO: NSUserDefaults
- (NSUserDefaults *)defaults {
    if (!_defaults) {
        _defaults = [NSUserDefaults standardUserDefaults];
    }
    return _defaults;
}

/**
 @param tintColor 导航栏颜色
 @param shadow 是否有分割线
 */
- (void)navBarTintColor:(UIColor *)tintColor withShadow:(BOOL)shadow {
    if (CGColorEqualToColor(tintColor.CGColor, UIColorWithNULL.CGColor)) {
        [self.baseNavigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
        [_baseNavigationBar setShadowImage:[UIImage new]];
    } else {
        [self.baseNavigationBar setBackgroundImage:[self imageWithBgColor:tintColor] forBarMetrics:UIBarMetricsDefault];
        if (shadow) {
            [_baseNavigationBar setShadowImage:[self imageWithBgColor:LINE_COLOR]];
        } else {
            [_baseNavigationBar setShadowImage:[UIImage new]];
        }
    }
}

#pragma mark -
#pragma mark - 设置titleView
- (void)setTitleView:(UIView *)titleView {
    
    if ([titleView isMemberOfClass:[UIView class]]) {
        self.baseNavigationItem.titleView = titleView;
    } else {
        UIView *nullView = [[UIView alloc] initWithFrame:titleView.bounds];
        [nullView addSubview:titleView];
        titleView.sd_layout.spaceToSuperView(UIEdgeInsetsMake(20.0, 0.0, 0.0, 0.0));
        self.baseNavigationItem.titleView = nullView;
    }
}

- (void)setTitle:(NSString *)title {
    self.baseNavigationItem.title = title;
}

#pragma mark -
#pragma mark -  左边按钮
- (void)leftBarItemWitihTitle:(NSString *)title actionSelector:(SEL)selector {
    if ([self respondsToSelector:selector]) {
        UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc] initWithTitle:title style:UIBarButtonItemStyleDone target:self action:selector];
        [leftBarItem setTintColor:UIColorWithRGB(37, 38, 46)];
        [leftBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:UIBoldFontWithSize(14),NSFontAttributeName, nil] forState:UIControlStateNormal];
        self.baseNavigationItem.leftBarButtonItem = leftBarItem;
    }
}


- (void)leftBarItemWitihImage:(NSString *)image actionSelector:(SEL)selector {
    if ([self respondsToSelector:selector]) {
        UIImage *leftBarButtonImage = [UIImageWithName(image) imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        self.baseNavigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:leftBarButtonImage style:UIBarButtonItemStylePlain target:self action:selector];
    }
}

- (void)popViewControllerAction {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark -  导航栏右边按钮
- (void)rightBarItemWitihTitle:(NSString *)title actionSelector:(SEL)selector {
    // 判断方法是否实现
    if ([self respondsToSelector:selector]) {
        
        self.rightBarItem.title = title;
        self.rightBarItem.target = self;
        self.rightBarItem.action = selector;
    }
}

- (void)rightBarItemWitihImage:(NSString *)image actionSelector:(SEL)selector {
    
    if ([self respondsToSelector:selector]) {
        UIImage *rightBarButtonImage = [UIImageWithName(image) imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        self.baseNavigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:rightBarButtonImage style:UIBarButtonItemStylePlain target:self action:selector];
    }
}


#pragma mark -
#pragma mark -  导航栏右边按钮
- (UIBarButtonItem *)rightBarItem {
    if (!_rightBarItem) {
        _rightBarItem = [[UIBarButtonItem alloc] init];
        [_rightBarItem setTintColor:UIColorWithRGB(37, 38, 46)];
        [_rightBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:UIBoldFontWithSize(15),NSFontAttributeName, nil] forState:UIControlStateNormal];
        self.baseNavigationItem.rightBarButtonItem = _rightBarItem;
    }
    return _rightBarItem;
}

// TODO: 右边按钮标题
- (void)setRightBtnTitle:(NSString *)rightBtnTitle {
    self.rightBarItem.title = rightBtnTitle;
}

-(void)setRightBtnTitleColor:(UIColor *)rightBtnTitleColor
{
    [self.rightBarItem setTintColor:rightBtnTitleColor];
}


- (void)rightBarItemWitihImgNames:(NSArray <NSString *> *)imageNames leftBarSelector:(SEL)leftSelectors rightBarSelector:(SEL)rightSelectors {
    
    NSMutableArray *barItems = [NSMutableArray arrayWithCapacity:2];
    
    if ([self respondsToSelector:leftSelectors]) {
        UIImage *rightBarButtonImage = [UIImageWithName(imageNames[0]) imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        [barItems addObject:[[UIBarButtonItem alloc] initWithImage:rightBarButtonImage style:UIBarButtonItemStylePlain target:self action:leftSelectors]];
    }
    
    if ([self respondsToSelector:rightSelectors]) {
        UIImage *rightBarButtonImage = [UIImageWithName(imageNames[1]) imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        [barItems addObject:[[UIBarButtonItem alloc] initWithImage:rightBarButtonImage style:UIBarButtonItemStylePlain target:self action:rightSelectors]];
    }
    
    if (barItems.count > 0) {
        self.baseNavigationItem.rightBarButtonItems = barItems;
    }
}






#pragma mark -
#pragma mark - 加载动画







#pragma mark -
#pragma mark - 控制器跳转
// tabbar跳转
- (void)popToHomePageWithTabIndex:(NSInteger)index {
    
    self.tabBarController.selectedIndex = index;
    [self.navigationController popToRootViewControllerAnimated:NO];
    
}


/**
 push转场
 
 @param classOrName 即将push到的控制器--可以说字符串、class
 */
- (void)pushViewControllerWithName:(id)classOrName {
    if (classOrName) {
        Class classs;
        if ([classOrName isKindOfClass:[NSString class]]) {
            NSString *name = classOrName;
            classs = NSClassFromString(name);
        } else if ([classOrName isSubclassOfClass:[HMBaseViewController class]]) {
            classs = classOrName;
        }
        
        UIViewController *vc = [classs new];
        [self.navigationController pushViewController:vc animated:YES];
    }
}


// 界面跳转并且删除本身
- (void)pushViewControllerAndRemoveSelfWithName:(id)classOrName {
    [self pushViewControllerWithName:classOrName];
    
    if (self.navigationController.viewControllers.count > 2) {
        [self removeFromParentViewController];
    }
}

//// push 到控制器
//- (void)pushViewController:(UIViewController *)viewController {
//    [self.navigationController pushViewController:viewController animated:YES];
//}


/**
 返回到栈内指定控制器
 
 @param classOrName 控制器名
 */
- (void)returnViewControllerWithName:(id)classOrName {
    if (classOrName) {
        Class classs;
        if ([classOrName isKindOfClass:[NSString class]]) {
            NSString *name = classOrName;
            classs = NSClassFromString(name);
        } else if ([classOrName isSubclassOfClass:[HMBaseViewController class]]) {
            classs = classOrName;
        }
        
        [self.navigationController.viewControllers enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(__kindof UIViewController * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isKindOfClass:classs]) {
                [self.navigationController popToViewController:obj animated:YES];
                *stop = YES;
                return;
            }
        }];
    }
}



//// present
//- (void)presentViewController:(UIViewController *)viewControllerToPresent animated:(BOOL)flag completion:(void (^)(void))completion {
//    
//    [self.view.window.layer addAnimation:self.animation forKey:nil];
//    [super presentViewController:viewControllerToPresent animated:flag completion:completion];
//    
//    
//    /*
//     常見的轉換類型（type）：
//     kCATransitionFade               //淡出
//     kCATransitionMoveIn          //覆盖原图
//     kCATransitionPush               //推出
//     kCATransitionReveal          //底部显出来
//     
//     设置其他动画类型的方法(type):
//     pageCurl   向上翻一页
//     pageUnCurl 向下翻一页
//     rippleEffect 滴水效果
//     suckEffect 收缩效果，如一块布被抽走
//     cube 立方体效果
//     oglFlip 上下翻转效果
//     
//     SubType:
//     kCATransitionFromRight
//     kCATransitionFromLeft    // 默认值
//     kCATransitionFromTop
//     kCATransitionFromBottom
//     
//     */
//    
//}
//
//
//- (void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion {
//    [self.view.window.layer addAnimation:self.animation forKey:nil];
//    [super dismissViewControllerAnimated:flag completion:completion];
//}


//- (CATransition *)animation {
//    
//    if (!_animation) {
//        _animation = [CATransition animation];
//        _animation.duration = 1.0;
////        _animation.timingFunction = UIViewAnimationCurveEaseIn;
//        _animation.type = @"rippleEffect";
////        _animation.type = kCATransitionPush;
//        _animation.subtype = kCATransitionFromBottom;
//    }
//    return _animation;
//}

// present到登录界面

- (BOOL )isLogin
{
    return [self isLogin:0];
}


- (BOOL )isLogin:(NSUInteger)tabBarIndex {
    if ([self.defaults objectForKey:@"token"]) {
        return YES;
    }else{
        
//        HMBaseNavigationController *navVC = [HMBaseNavigationController new];
//        LoginViewController *loginVC = [LoginViewController new];
//        loginVC.tabBatIndex = tabBarIndex;
//        [navVC addChildViewController:loginVC];
//        [self presentViewController:navVC animated:YES completion:nil];
    }
    return NO;
}



- (NSString *)getLocationLon
{
    return [self.defaults objectForKey:@"longitude"];
}

- (NSString *)getLocationLat
{
    return [self.defaults objectForKey:@"latitude"];

}

- (NSString *)getAccessToken
{
    return [self.defaults objectForKey:@"token"];

}

- (NSString *)getDeviceOnlyToken
{
    return [self.defaults objectForKey:@"randomToken"];
}

- (void)needreturnBtn
{
    UIButton *back = [[UIButton alloc] initWithFrame:CGRectMake(10, 20, 44, 44)];
//    [back setTitle:@"we" forState:0];
    
    [back addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [back setImage:[UIImage imageNamed:@"nav_return"] forState:0];
    [self.baseNavigationBar addSubview:back];
}

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}


//获取当地时间
- (NSString *)getCurrentTime {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyyMMdd"];
    NSString *dateTime = [formatter stringFromDate:[NSDate date]];
    return dateTime;
}

//获取当地时间
- (NSString *)getCurrentTimeWithFormatter{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSString *dateTime = [formatter stringFromDate:[NSDate date]];
    return dateTime;
}


#pragma mark -
#pragma mark -  颜色转图片
- (UIImage *)imageWithBgColor:(UIColor *)color {
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}




@end
