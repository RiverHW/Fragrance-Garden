//
//  HMBaseNavigationBar.h
//  IngotEshop
//
//  Created by YHM on 2017/4/25.
//  Copyright © 2017年 陈123. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMBaseNavigationBar : UINavigationBar

@end
