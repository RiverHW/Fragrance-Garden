//
//  HMBaseNavigationBar.m
//  IngotEshop
//
//  Created by YHM on 2017/4/25.
//  Copyright © 2017年 陈123. All rights reserved.
//

#import "HMBaseNavigationBar.h"

@implementation HMBaseNavigationBar


#pragma mark -
#pragma mark - 防止响应区域过大
-(UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    
    if ([self pointInside:point withEvent:event]) {
        self.userInteractionEnabled = YES;
    } else {
        self.userInteractionEnabled = NO;
    }
    
    return [super hitTest:point withEvent:event];
}

@end
