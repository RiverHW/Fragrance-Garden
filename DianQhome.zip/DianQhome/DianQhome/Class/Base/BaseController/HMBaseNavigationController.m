//
//  HMBaseNavigationController.m
//  SearchCard
//
//  Created by YHM on 2017/3/22.
//  Copyright © 2017年 welink. All rights reserved.
//

#import "HMBaseNavigationController.h"

@interface HMBaseNavigationController ()<UIGestureRecognizerDelegate>

@end

@implementation HMBaseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setNavigationBarHidden:NO];       // 使导航条有效
    [self.navigationBar setHidden:YES];     // 隐藏导航条，但由于导航条有效，系统的返回按钮页有效，所以可以使用系统的右滑返回手势。
}


- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    if (self.viewControllers.count > 0) {
        [viewController setHidesBottomBarWhenPushed:YES];
//        self.navigationBarHidden = NO;
    }
    [super pushViewController:viewController animated:animated];
}




@end
