//
//  HMBaseViewController.h
//  SearchCard
//
//  Created by YHM on 2017/3/22.
//  Copyright © 2017年 welink. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HMBaseNavigationBar.h"

@interface HMBaseViewController : UIViewController

@property(nonatomic,strong)NSUserDefaults *defaults;        // 缓存

/**
 *  导航栏
 */
@property (nonatomic, strong) HMBaseNavigationBar *baseNavigationBar;
@property (nonatomic, strong) UINavigationItem *baseNavigationItem;
@property (nonatomic, strong) UIView *titleView;         // Custom view to use in lieu of a title. May be sized horizontally. Only used when item is topmost on the stack.

/**
 @param tintColor 导航栏颜色
 @param shadow 是否有分割线 --- 分割线颜色固定
 */
- (void)navBarTintColor:(UIColor *)tintColor withShadow:(BOOL)shadow;


#pragma mark -
#pragma mark - 左边按钮

/**
 自定义左边按钮
 
 @param title 文字     \     image  图片名
 @param selector 事件
 */
- (void)leftBarItemWitihTitle:(NSString *)title actionSelector:(SEL)selector;
- (void)leftBarItemWitihImage:(NSString *)image actionSelector:(SEL)selector;

- (void)popViewControllerAction;

#pragma mark -
#pragma mark - 右边按钮
/**
 自定义右边按钮
 
 @param title 文字   \    image  图片名
 @param selector 事件
 */
- (void)rightBarItemWitihTitle:(NSString *)title actionSelector:(SEL)selector;
- (void)rightBarItemWitihImage:(NSString *)image actionSelector:(SEL)selector;
- (void)rightBarItemWitihImgNames:(NSArray <NSString *> *)imageNames leftBarSelector:(SEL)leftSelectors rightBarSelector:(SEL)rightSelectors;

- (void)needreturnBtn;

@property (nonatomic, copy) NSString *rightBtnTitle;        // 右边按钮标题
@property (nonatomic, strong) UIColor *rightBtnTitleColor;        // 右边按钮标题


#pragma mark -
#pragma mark - 加载动画


#pragma mark -
#pragma mark - 界面切换
//不需要传参数的push 只需告诉类名字符串
- (void)pushViewControllerWithName:(id)classOrName;
// push并且删除自身控制器
- (void)pushViewControllerAndRemoveSelfWithName:(id)classOrName;
//// push 到控制器
//- (void)pushViewController:(UIViewController *)viewController;
//回到当前模块导航下的某一个页面
- (void)returnViewControllerWithName:(id)classOrName;
//切到指定模块下
- (void)popToHomePageWithTabIndex:(NSInteger)index;



// 判断是否已经登入 如果没有登入的情况下 会自动跳转到登入界面
- (BOOL)isLogin;
- (BOOL )isLogin:(NSUInteger)tabBarIndex;


//精度 纬度 accesstoken app唯一标识
- (NSString *)getLocationLon;
- (NSString *)getLocationLat;
- (NSString *)getAccessToken;
- (NSString *)getDeviceOnlyToken;

//获取当地时间
- (NSString *)getCurrentTime;
//获取当地时间yyyy--mm--dd
- (NSString *)getCurrentTimeWithFormatter;


@end
