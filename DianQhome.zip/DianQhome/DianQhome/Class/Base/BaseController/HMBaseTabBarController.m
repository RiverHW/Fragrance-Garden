//
//  HMBaseTabBarController.m
//  SearchCard
//
//  Created by YHM on 2017/3/22.
//  Copyright © 2017年 welink. All rights reserved.
//

#import "HMBaseTabBarController.h"
#import "HMBaseNavigationController.h"
#import "HMBaseViewController.h"
#import "MessageViewController.h"
#import "HomeViewController.h"
#import "MineViewController.h"
@interface HMBaseTabBarController ()<UITabBarControllerDelegate>

@property (nonatomic, assign) NSUInteger tabBarIndex;

@end

@implementation HMBaseTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.delegate = self;
    
    [self itemChildViewController:[HomeViewController class] itemTitle:@"详情" itemImageName:@"detailun" itemSelectedImageName:@"detailSele"];
    [self itemChildViewController:[MessageViewController class] itemTitle:@"评分" itemImageName:@"Scoreun" itemSelectedImageName:@"ScoreSele"];
    [self itemChildViewController:[MineViewController class] itemTitle:@"我的" itemImageName:@"Mineun" itemSelectedImageName:@"mineSele"];
    // 字体颜色 选中
    [[UITabBarItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName : Tab_Text_Color} forState:UIControlStateSelected];
    // 字体颜色 未选中
    [[UITabBarItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName : Tab_Text_Unseleted_Color} forState:UIControlStateNormal];
    
    // 设置tabbar不透明
    self.tabBar.translucent = NO;
    
}



#pragma mark -
#pragma mark - tabBar
- (void)itemChildViewController:(Class)class itemTitle:(NSString*)title itemImageName:(NSString*)image itemSelectedImageName:(NSString*)selectedImage {
    HMBaseViewController *vc = [class new];
    vc.tabBarItem.image = [[UIImage imageNamed:image] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc.tabBarItem.title = title;
    //导航
    HMBaseNavigationController *baseNav = [[HMBaseNavigationController alloc] initWithRootViewController:vc];
//    baseNav.navigationBar.topItem.title = title;
    [self addChildViewController:baseNav];
    
}


////点击的时候触发的方法
//-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
//{
//    if (self.selectedIndex == 2) {
////        if ([self isLogin] && !_carModelArray) {
////            [self requestShopingCarModelPageIndex:1];
////        }
//    }
//    
//}
//防止通个页面一直点击tabbar 的方法
-(BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(HMBaseNavigationController *)viewController{
    
//    HMBaseNavigationController *tbselect = tabBarController.selectedViewController;
    
//    HMBaseViewController *VC = [viewController.viewControllers objectAtIndex:0];
//    if ([VC.defaults objectForKey:@"token"] || [VC isKindOfClass:[HomeViewController class]] || [VC isKindOfClass:[MerchantsAllianceViewController class]]) {
//        return YES;
//    } else {
//        [VC isLogin];
//        _tabBarIndex = [tabBarController.viewControllers indexOfObject:viewController];
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(againLoadingViewController) name:@"loginSuccessRefresh" object:nil];
//        return NO;
//    }
    return YES;
    
}

//- (void)addNavController {
//    for (NSUInteger i = 2; i < 4; i++) {
//        HMBaseNavigationController *navController = [self.viewControllers objectAtIndex:i];
//        HMBaseViewController *baseVC = [navController.viewControllers objectAtIndex:0];
//        if ([baseVC isViewLoaded]) {
//            if (navController.viewControllers.count > 1) {
//                HMBaseViewController *popVC = [navController.viewControllers lastObject];
//                [popVC.navigationController popViewControllerAnimated:NO];
//            }
//            [baseVC removeFromParentViewController];
//            if (i == 2) {
//                baseVC = [KaCircleViewController new];
//            } else {
//                baseVC = [MineViewController new];
//            }
//            [navController addChildViewController:baseVC];
//        }
//    }
//}



- (void)againLoadingViewController {
    [self addNavController];
    [self setSelectedIndex:_tabBarIndex];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"loginSuccessRefresh" object:nil];
}


@end
