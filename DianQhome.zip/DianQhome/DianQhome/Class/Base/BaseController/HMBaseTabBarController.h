//
//  HMBaseTabBarController.h
//  SearchCard
//
//  Created by YHM on 2017/3/22.
//  Copyright © 2017年 welink. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMBaseTabBarController : UITabBarController

- (void)addNavController;


@end
